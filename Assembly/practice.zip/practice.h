
#define THE_BASICS_TEST_NUM 7

#define CONTROL_FLOW_TEST_NUM 4

#define POINTERS_TEST_NUM 7
/*The structure we will be using*/
typedef struct{
    int x;
    int y;
}package;

/*The Basics*/
int return_ten();
int add_two_ints(int,int);
short add_two_shorts(short,short);
int or_masking(int);
int and_masking(int);
int divide_by_shift(int);
int just_divide(int,int);



/*Control Flow*/
int basic_conditional(int);

int nested_conditional(int);

int for_loop(int);

int while_loop(int, int);



/*Pointer, dereferencing, and structures*/

void simple_dereference(int*);

void simple_dereference2(int*);

int inside_the_array(int *);

int inside_the_array2(short *);

int inside_the_array3(int *, int);

int star_struct(package *);
int star_struct2(package);

